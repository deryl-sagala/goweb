# GoWeb

Small and lightweight Golang Web Framework[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://choosealicense.com/licenses/mit/)[![Isues](https://img.shields.io/github/issues/DerylDarren/goweb
)](https://github.com/DerylDarren/goweb/issues)

## Authors

- [@DerylDarren](https://www.github.com/DerylDarren)
- [@deryl-sagala](https://www.github.com/deryl-sagala)


## Contributing

Contributions are always welcome!

## Documentation

[Documentation](https://DerylDarren.github.io/goweb)
